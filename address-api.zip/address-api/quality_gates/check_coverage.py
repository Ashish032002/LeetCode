#!/usr/bin/env python3

import sys
from bs4 import BeautifulSoup

# Define the coverage threshold
THRESHOLD = 95.0  # 95%

def get_coverage_from_html(file_path):
    """Extract the overall statements coverage percentage from the HTML report."""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            soup = BeautifulSoup(file, 'html.parser')
            # Find the "Statements" coverage percentage
            # It’s in a div with class 'fl pad1y space-right2' and a span with class 'strong'
            statements_div = soup.find('div', class_='fl pad1y space-right2')
            if statements_div:
                coverage_span = statements_div.find('span', class_='strong')
                if coverage_span:
                    # Extract the percentage (e.g., "65.55%") and convert to float
                    coverage_text = coverage_span.text.strip().rstrip('%')
                    return float(coverage_text)
            print("Error: Could not find coverage percentage in the report.", file=sys.stderr)
            return None
    except Exception as e:
        print(f"Error reading or parsing HTML file: {e}", file=sys.stderr)
        return None

def evaluate_coverage(coverage, threshold):
    """Evaluate coverage against the threshold and exit accordingly."""
    if coverage is None:
        print("Coverage data not found. Failing the check.", file=sys.stderr)
        sys.exit(1)
    print(f"Coverage: {coverage}% | Threshold: {threshold}%")
    if coverage < threshold:
        print(f"Coverage {coverage}% is below the threshold of {threshold}%. Failing.", file=sys.stderr)
        sys.exit(1)  # Exit with failure status
    else:
        print(f"Coverage {coverage}% meets or exceeds the threshold of {threshold}%. Passing.")
        sys.exit(0)  # Exit with success status

def main():
    # Path to your HTML coverage report (adjust as needed)
    report_path = "coverage/lcov-report/index.html"  # Example path
    # Extract coverage from the report
    coverage = get_coverage_from_html(report_path)
    # Evaluate against the threshold
    evaluate_coverage(coverage, THRESHOLD)

if __name__ == "__main__":
    main()
