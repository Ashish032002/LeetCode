
import json
import sys
 
def load_report(file_path):
    """Load JSON report from file"""
    with open(file_path, 'r') as f:
        return json.load(f)
 
def check_sast_report(sast_report):
    """Check Static Application Security Testing (SAST) report against thresholds"""
    vulnerabilities = len(sast_report.get('vulnerabilities', []))
    vulnerabilities_list = sast_report.get('vulnerabilities')
    critical_vulnerabilities = 0
    high_vulnerabilities = 0
    medium_vulnerabilities = 0
    low_vulnerabilities = 0
    unknown_vulnerabilities = 0
    for i in vulnerabilities_list:
        if i["severity"] == "Low":
            low_vulnerabilities+=1
        elif i["severity"] == "Medium":
            medium_vulnerabilities+=1
        elif i["severity"] == "High":
            high_vulnerabilities+=1
        elif i["severity"] == "Critical":
            critical_vulnerabilities+=1
        else:
            unknown_vulnerabilities+=1


    print(f"Critical Vulnerabilities: {critical_vulnerabilities}")
    print(f"High Vulnerabilities: {high_vulnerabilities}")
    print(f"Medium Vulnerabilities: {medium_vulnerabilities}")
    print(f"Low Vulnerabilities: {low_vulnerabilities}")
    print(f"Unknown Vulnerabilities: {unknown_vulnerabilities}")
    print(f"Total SAST Vulnerabilities: {vulnerabilities}")
    
    if critical_vulnerabilities > 0 or high_vulnerabilities > 0:
        print(f"SAST: Code has {critical_vulnerabilities} Critical Vulnerabilities and {high_vulnerabilities} High Vulnerabilities")
        return False
 
    print("SAST: Quality check passed.")
    return True
 
sast_report = load_report("gl-sast-report.json")
 
# Check the report
sast_check = check_sast_report(sast_report)
 
# Exit with non-zero status if critical vulnerabilities are found
if not sast_check:
    sys.exit(1)