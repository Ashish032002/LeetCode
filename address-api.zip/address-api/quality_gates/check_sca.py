import json
import sys

def load_report(file_path):
    """Load JSON report from file"""
    with open(file_path, 'r') as f:
        return json.load(f)

def check_sca_report(sca_report):
    """Check Static Code Analysis (SCA) report against thresholds"""
    vulnerabilities = len(sca_report.get('vulnerabilities', []))
    vulnerabilities_list = sca_report.get('vulnerabilities')
    critical_vulnerabilities = 0
    high_vulnerabilities = 0
    medium_vulnerabilities = 0
    low_vulnerabilities = 0
    unknown_vulnerabilities = 0
    for i in vulnerabilities_list:
        if i["severity"] == "Low":
            low_vulnerabilities+=1
        elif i["severity"] == "Medium":
            medium_vulnerabilities+=1
        elif i["severity"] == "High":
            high_vulnerabilities+=1
        elif i["severity"] == "Critical":
            critical_vulnerabilities+=1
        else:
            unknown_vulnerabilities+=1


    print(f"Critical Vulnerabilities: {critical_vulnerabilities}")
    print(f"High Vulnerabilities: {high_vulnerabilities}")
    print(f"Medium Vulnerabilities: {medium_vulnerabilities}")
    print(f"Low Vulnerabilities: {low_vulnerabilities}")
    print(f"Unknown Vulnerabilities: {unknown_vulnerabilities}")
    print(f"Total SCA Vulnerabilities: {vulnerabilities}")
    
    if critical_vulnerabilities > 0 or high_vulnerabilities > 0:
        print(f"SCA: Code has {critical_vulnerabilities} Critical Vulnerabilities and {high_vulnerabilities} High Vulnerabilities")
        return False


    print("SCA: Quality check passed.")
    return True


sca_report = load_report("gl-dependency-scanning-report.json")
sca_check = check_sca_report(sca_report)

# Exit with non-zero status if critical vulnerabilities are found
if not sca_check:
    sys.exit(1)
 