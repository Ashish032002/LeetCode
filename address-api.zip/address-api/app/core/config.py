
import os

class Settings:
    """
    A class to hold application settings, read from environment variables.
    Note: This no longer uses Pydantic and will not automatically read from a .env file.
    """
    app_name: str = os.getenv("APP_NAME", "Address Validation API")
    database_url: str | None = os.getenv("DATABASE_URL")
    host: str = os.getenv("HOST", "0.0.0.0")
    port: int = int(os.getenv("PORT", "8080"))


settings = Settings()
