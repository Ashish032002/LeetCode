from fastapi import FastAPI, logger
from app.api.v1.address import router as address_router
from app.core.config import settings

app = FastAPI(
    title="Address Validation API",
    version="1.0.0",
    description="Single-address validation API backed by the existing validator logic.",
)
app.include_router(address_router, prefix="/avl")

