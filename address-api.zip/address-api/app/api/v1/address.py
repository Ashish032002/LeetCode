
from fastapi import APIRouter, HTTPException
from app.models.schemas import AddressRequest, AddressValidationResponse
from app.services.address_validator import validate_single_address

router = APIRouter(prefix="/v1", tags=["address-validation"])

@router.get("/health", summary="Health check")
async def health_check():
    return {"status": "OK"}

@router.post(
    "/validate-address",
    response_model=AddressValidationResponse,
    summary="Validate a single postal address",
)
async def validate_address(request: AddressRequest) -> AddressValidationResponse:
    try:
        response = validate_single_address(request)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return response
