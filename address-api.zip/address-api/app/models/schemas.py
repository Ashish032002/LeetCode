
from typing import List, Literal, Optional, Any
from pydantic import BaseModel, Field
from .custom_schemas import CustomValidationResult

class AddressRequest(BaseModel):
    address1: str = Field(..., description="First line of address")
    address2: Optional[str] = Field(None, description="Second line of address")
    address3: Optional[str] = Field(None, description="Third line of address or landmark")
    city: Optional[str] = Field(None, description="City name as provided by user")
    state: Optional[str] = Field(None, description="State name as provided by user")
    pincode: Optional[str] = Field(None, description="Postal PIN code as provided by user")
    country: Optional[str] = Field(None, description="Country name as provided by user")

class AddressValidationResponse(BaseModel):
    results: List[CustomValidationResult]
    status: Literal["OK", "ZERO_RESULTS", "INVALID_REQUEST", "REQUEST_DENIED", "UNKNOWN_ERROR"]
    reason: Optional[str] = None
