
from typing import Dict, List, Any
import pandas as pd
import json

from app.models.schemas import (
    AddressRequest, AddressValidationResponse
)
from app.services.validate_addresses_9_final import validate_inputs_df

def _parse_list(val: Any) -> List[str]:
    if isinstance(val, str):
        try:
            return json.loads(val)
        except json.JSONDecodeError:
            return []
    return []

def validate_single_address(req: AddressRequest) -> AddressValidationResponse:
    # Create a DataFrame from the single request
    input_data = {
        "id": [1],  # Assign a dummy ID
        "address1": [req.address1],
        "address2": [req.address2],
        "address3": [req.address3],
        "city": [req.city],
        "state": [req.state],
        "pincode": [req.pincode],
        "country": [req.country],
    }
    inputs_df = pd.DataFrame(input_data)

    # Call the core validation logic
    result_df = validate_inputs_df(inputs_df)

    if result_df.empty:
        return AddressValidationResponse(results=[], status="ZERO_RESULTS", reason="No validation result was produced.")

    # Extract the single result row
    row = result_df.iloc[0]

    def wrap(value: Any, type_name: str) -> Dict[str, Any]:
        """Ensure value is always a list and wrap it in the desired dictionary structure."""
        if value is None:
            return {"value": [], "type": type_name}
        if not isinstance(value, list):
            value = [value]
        return {"value": value, "type": type_name}

    address_components = [
        # Normalized Output
        wrap(row.get("output_pincode"), "pincode"),
        wrap(row.get("output_city"), "city"),
        wrap(row.get("output_state"), "state"),
        wrap(row.get("output_country"), "country"),
        wrap(row.get("local_address"), "local_address"),

        # Flags
        wrap(int(row.get("t30_city_possible", 0)), "t30_city_possible"),
        wrap(int(row.get("foreign_country_possible", 0)), "foreign_country_possible"),
        wrap(int(row.get("pincode_found", 0)), "pincode_found"),
        wrap(int(row.get("ambiguous_address_flag", 0)), "ambiguous_address_flag"),

        # Possible values
        wrap(_parse_list(row.get("all_possible_countries")), "all_possible_countries"),
        wrap(_parse_list(row.get("all_possible_states")), "all_possible_states"),
        wrap(_parse_list(row.get("all_possible_cities")), "all_possible_cities"),
        wrap(_parse_list(row.get("all_possible_pincodes")), "all_possible_pincodes"),

        # Matching scores
        wrap(float(row.get("city_value_match", 0.0)), "city_value_match"),
        wrap(float(row.get("city_consistency_with_pincode", 0.0)), "city_consistency_with_pincode"),
        wrap(float(row.get("city_ambiguity_penalty", 0.0)), "city_ambiguity_penalty"),
        wrap(float(row.get("state_value_match", 0.0)), "state_value_match"),
        wrap(float(row.get("state_consistency_with_pincode", 0.0)), "state_consistency_with_pincode"),
        wrap(float(row.get("state_ambiguity_penalty", 0.0)), "state_ambiguity_penalty"),
        wrap(float(row.get("country_value_match", 0.0)), "country_value_match"),
        wrap(float(row.get("country_consistency_with_pincode", 0.0)), "country_consistency_with_pincode"),
        wrap(float(row.get("country_ambiguity_penalty", 0.0)), "country_ambiguity_penalty"),
        wrap(float(row.get("overall_score", 0.0)), "overall_score"),
    ]

    # Join only the non-empty parts of the address to avoid extra commas
    address_parts = [
        row.get("local_address"),
        row.get("output_city"),
        row.get("output_state"),
        row.get("output_country"),
        row.get("output_pincode"),
    ]
    formatted_address = ",".join(
        str(part) for part in address_parts if part is not None and str(part).strip()
    )

    result = {
        "address_components": address_components,
        "formatted_address": formatted_address,
    }
    
    return AddressValidationResponse(results=[result], status="OK", reason=row.get("reason", "") or "Address validated successfully")
