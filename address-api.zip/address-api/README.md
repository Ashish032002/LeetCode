
# Address Validation API (FastAPI + GKE ready)

- Single endpoint: `POST /api/v1/validate-address`
- Health check: `GET /api/v1/health`
- Backed by the existing `validate_addresses_9_final.py` logic.
- Designed for Postgres/AlloyDB via SQLAlchemy (`DATABASE_URL` env var).

To run locally:

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8080
```
