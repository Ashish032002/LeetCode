import os, pandas as pd
from sqlalchemy import text
from db_config import get_engine

def _pick(cols, cands):
    look = {c.lower().replace(' ',''): c for c in cols}
    for cand in cands:
        k = cand.lower().replace(' ','')
        if k in look: return look[k]
    return None

def main():
    here = os.path.dirname(__file__)
    for path in [os.path.join(here, "Countries.xlsx"), os.path.join(here, "countries.xlsx")]:
        if os.path.exists(path):
            df = pd.read_excel(path)
            break
    else:
        raise FileNotFoundError("Countries.xlsx not found.")

    col = _pick(df.columns, ["Country", "name"])
    if not col: raise ValueError("Countries.xlsx must contain 'Country' column.")

    out = (df[[col]].copy()
        .rename(columns={col: "name"})
        .assign(name=lambda d: d["name"].astype(str).str.strip().str.title())
        .dropna()
        .drop_duplicates()
    )

    eng = get_engine()
    with eng.begin() as con:
        con.execute(text("DELETE FROM ref.countries"))
        out.to_sql("countries", con, schema="ref", if_exists="append", index=False, method="multi")
    print(f"Loaded {len(out)} rows into ref.countries")

if __name__=="__main__":
    main()
