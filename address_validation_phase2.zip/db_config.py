import os
from sqlalchemy import create_engine

def _build_engine_from_env():
    # DSN override
    dsn = os.getenv("DB_DSN")
    if dsn:
        return create_engine(dsn, pool_pre_ping=True)

    # Parts
    dialect = os.getenv("DB_DIALECT", "").strip()
    if dialect:
        host = os.getenv("DB_HOST", "localhost")
        port = os.getenv("DB_PORT", "5432")
        name = os.getenv("DB_NAME", "address_validation")
        user = os.getenv("DB_USER", "postgres")
        pw   = os.getenv("DB_PASS", "postgres")
        url  = f"{dialect}://{user}:{pw}@{host}:{port}/{name}"
        return create_engine(url, pool_pre_ping=True)

    # Fallback to SQLite (local file)
    db_path = os.path.join(os.getcwd(), "address_validation_phase2.db")
    return create_engine(f"sqlite:///{db_path}", echo=False, future=True)

def get_engine():
    return _build_engine_from_env()
