import os, re, json, math
import pandas as pd
from sqlalchemy import text
from db_config import get_engine

try:
    from rapidfuzz import fuzz
    def sim(a,b): return fuzz.token_set_ratio(str(a or ""), str(b or ""))/100.0
except Exception:
    import difflib
    def sim(a,b): return difflib.SequenceMatcher(None, str(a or "").lower(), str(b or "").lower()).ratio()

CITY_THR = 0.80
STATE_THR = 0.80
COUNTRY_THR = 0.80
PINCODE_RE = re.compile(r"(?<!\d)(\d{6})(?!\d)")

def clean_text(s):
    s = str(s or "")
    s = re.sub(r"[^0-9A-Za-z ,./-]+", " ", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()

def pick_pincode(text):
    m = PINCODE_RE.search(text or "")
    return m.group(1) if m else None

def main(limit=1000):
    eng = get_engine()
    with eng.begin() as con:
        postal = pd.read_sql("SELECT city,state,pincode,country FROM ref.postal_pincode", con)
        rta    = pd.read_sql("SELECT city,state,pincode,country FROM ref.rta_pincode", con)
        t30    = pd.read_sql("SELECT city FROM ref.t30_cities", con)["city"].str.title().unique().tolist()
        world  = pd.read_sql("SELECT city,country FROM ref.world_cities", con)
        countries = pd.read_sql("SELECT name FROM ref.countries", con)["name"].str.title().unique().tolist()
        inputs = pd.read_sql(f"SELECT * FROM input.addresses ORDER BY id LIMIT {int(limit)}", con)

    pin_to_rows = {}
    for df, src in [(postal, "postal"), (rta, "rta")]:
        for _, r in df.iterrows():
            pin_to_rows.setdefault(r["pincode"], []).append((src, r))

    results = []
    audit   = []

    for _, row in inputs.iterrows():
        input_id = int(row["id"])
        addr_text = clean_text(" ".join([str(row.get(c) or "") for c in
                          ["address1","address2","address3","city","state","country","pincode"]]))

        text_pin = pick_pincode(addr_text) or (str(row.get("pincode") or "").strip() or None)
        pin_rows = pin_to_rows.get(text_pin, []) if text_pin else []
        pincode_found = 1 if pin_rows else 0

        chosen_pin = None
        chosen_city = None
        chosen_state = None
        chosen_country = None

        score_pin_input_city = None
        score_pin_city_db = None
        score_pin_input_state = None
        score_pin_state_db = None
        score_pin_input_country = None
        score_pin_country_db = None

        all_pins = set()
        all_cities = set()
        all_states = set()
        all_countries = set()

        if text_pin and pin_rows:
            chosen_pin = text_pin
            for src, r in pin_rows:
                all_cities.add(str(r["city"]).title())
                all_states.add(str(r["state"]).title())
                all_countries.add(str(r["country"]).title())
                audit.append({"input_id": input_id, "match_type": "pincode", "candidate": text_pin, "score": 1.0, "source": src})

            input_city = str(row.get("city") or "").title()
            input_state= str(row.get("state") or "").title()
            input_country = str(row.get("country") or "").title()

            best_city = None; best_city_score = -1
            best_state= None; best_state_score= -1
            for src, r in pin_rows:
                c = str(r["city"]).title(); s = str(r["state"]).title(); k = str(r["country"]).title()
                sc_city_in = sim(c, input_city) if input_city else 0
                sc_state_in= sim(s, input_state) if input_state else 0
                sc_country_in= sim(k, input_country) if input_country else 0
                if sc_city_in > best_city_score: best_city, best_city_score = c, sc_city_in
                if sc_state_in > best_state_score: best_state, best_state_score = s, sc_state_in
                score_pin_city_db = 1.0
                score_pin_state_db= 1.0
                score_pin_country_db= 1.0

            score_pin_input_city = best_city_score if best_city is not None else None
            score_pin_input_state= best_state_score if best_state is not None else None
            score_pin_input_country = sim("India", input_country) if input_country else None

            chosen_city = best_city
            chosen_state= best_state
            chosen_country = "India"

        if not chosen_pin:
            tokens = [w.title() for w in re.split(r"[^A-Za-z]+", addr_text) if w]
            candidate_cities = set([str(row.get("city") or "").title()]) | (set(tokens) & set(world["city"].str.title().unique().tolist()))
            best_c = None; best_c_score = -1.0; best_cc = None
            for c in candidate_cities:
                wc = world[world["city"].str.title() == c]
                for _, pr in wc.iterrows():
                    sc = sim(c, str(row.get("city") or ""))
                    if sc > best_c_score:
                        best_c_score = sc; best_c = c; best_cc = str(pr["country"]).title()
                    audit.append({"input_id": input_id, "match_type": "city", "candidate": c, "score": sc, "source": "world_cities"})
            if best_c:
                chosen_city = best_c
                chosen_country = best_cc

            token_state = str(row.get("state") or "").title()
            chosen_state = token_state if token_state else None

            input_country = str(row.get("country") or "").title()
            best_k = None; best_k_score = -1.0
            for k in set([input_country] + countries):
                sc = sim(k, input_country) if input_country else 0
                if sc > best_k_score:
                    best_k_score = sc; best_k = k
                audit.append({"input_id": input_id, "match_type": "country", "candidate": k, "score": sc, "source": "countries"})
            chosen_country = best_k or chosen_country

            score_pin_input_city = None
            score_pin_city_db = None
            score_pin_input_state = None
            score_pin_state_db = None
            score_pin_input_country = None
            score_pin_country_db = None

        flag_t30 = 1 if (chosen_city and chosen_city.title() in set(t30)) else 0
        flag_foreign = 1 if (chosen_country and chosen_country != "India") else 0

        all_pins_list = []
        all_cities_list = sorted(list(all_cities or ({chosen_city} if chosen_city else set())))
        all_states_list = sorted(list(all_states or ({chosen_state} if chosen_state else set())))
        all_countries_list = sorted(list(all_countries or ({chosen_country} if chosen_country else set())))

        results.append({
            "input_id": input_id,
            "chosen_pincode": chosen_pin,
            "chosen_city": chosen_city,
            "chosen_state": chosen_state,
            "chosen_country": chosen_country,
            "score_pincode_input_city": score_pin_input_city,
            "score_pincode_city_db": score_pin_city_db,
            "score_pincode_input_state": score_pin_input_state,
            "score_pincode_state_db": score_pin_state_db,
            "score_pincode_input_country": score_pin_input_country,
            "score_pincode_country_db": score_pin_country_db,
            "flag_t30_possible": flag_t30,
            "flag_foreign_country_possible": flag_foreign,
            "flag_pincode_found": 1 if chosen_pin else 0,
            "source_used": "pincode" if chosen_pin else "heuristic",
            "all_pincodes": json.dumps(all_pins_list, ensure_ascii=False),
            "all_cities": json.dumps(all_cities_list, ensure_ascii=False),
            "all_states": json.dumps(all_states_list, ensure_ascii=False),
            "all_countries": json.dumps(all_countries_list, ensure_ascii=False),
        })

    out_df = pd.DataFrame(results)
    audit_df = pd.DataFrame(audit) if audit else pd.DataFrame(columns=["input_id","match_type","candidate","score","source"])

    outputs_dir = os.path.join(os.getcwd(), "outputs")
    os.makedirs(outputs_dir, exist_ok=True)
    excel_path = os.path.join(outputs_dir, "validation_results.xlsx")
    with pd.ExcelWriter(excel_path) as xl:
        out_df.to_excel(xl, index=False, sheet_name="results")
        audit_df.to_excel(xl, index=False, sheet_name="audit")

    eng = get_engine()
    with eng.begin() as con:
        out_df.to_sql("validation_result", con, schema="output", if_exists="append", index=False, method="multi")
        audit_df.to_sql("audit_matches", con, schema="output", if_exists="append", index=False, method="multi")

    print(f"Wrote {len(out_df)} results to output.validation_result and Excel at: {excel_path}")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=1000, help="Number of input rows to process (default: 1000)")
    args = ap.parse_args()
    main(limit=args.limit)
