# Address Validation — Phase 2 (Fresh Implementation)

This implementation recreates the database and the entire ingestion + validation pipeline **from scratch** based on your updated requirements.

## Highlights
- Unified **schema** with **serial primary keys** on *every* table.
- Modular **uploaders** for each reference dataset.
- Strict **matching rules**: pincode-first, then country/state/city with **fuzzy ≥ 0.80**.
- **T30 city** and **Foreign country** flags, plus **pincode existence** flag.
- **All possible matches** captured in JSON columns for transparency/audit.
- Batch processing with a default **chunk size = 1000** inputs.
- Results persisted to an **output schema** and also exported to **Excel**.
- Works out-of-the-box with **SQLite**. Switch to **Postgres/AlloyDB** using env vars.

## Quick Start
```bash
# 1) Install deps
pip install sqlalchemy pandas openpyxl rapidfuzz

# 2) Create schema
python create_schema.py

# 3) Upload reference data (do all)
python upload_countries.py
python upload_world_cities.py
python upload_t30_cities.py
python upload_state_abbrev.py
python upload_postal_pincode.py
python upload_rta_pincode.py
python upload_input_addresses.py  # loads input list

# 4) Validate (first 1000 records by default; use --limit to change)
python validate_addresses.py --limit 1000

# 5) Check outputs
# - DB tables in 'output' schema: validation_result, audit_matches
# - Excel: ./outputs/validation_results.xlsx
```

## Postgres/AlloyDB
Set these env vars (SQLAlchemy style):  
- `DB_DSN=postgresql+psycopg2://USER:PASS@HOST:PORT/DBNAME`

Or provide parts:
- `DB_DIALECT=postgresql+psycopg2`
- `DB_HOST=localhost`
- `DB_PORT=5432`
- `DB_NAME=address_validation`
- `DB_USER=postgres`
- `DB_PASS=secret`

If **DB_DSN** is set, it takes precedence. Otherwise it builds from parts. If none given, it falls back to **SQLite** (`./address_validation_phase2.db`).

## Files
- `db_config.py`: DB connection
- `create_schema.py`: builds Phase‑2 schema
- `upload_*.py`: loaders for each dataset
- `validate_addresses.py`: the matching logic + batch export to Excel
