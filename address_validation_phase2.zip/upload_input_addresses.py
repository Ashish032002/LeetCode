import os, pandas as pd
from sqlalchemy import text
from db_config import get_engine

def main():
    here = os.path.dirname(__file__)
    for fn in ["Input_address_2.xlsx", "input_addresses.xlsx"]:
        path = os.path.join(here, fn)
        if os.path.exists(path):
            df = pd.read_excel(path)
            break
    else:
        raise FileNotFoundError("Input_address_2.xlsx not found.")

    rename = {}
    for c in df.columns:
        lc = c.strip().lower().replace(" ", "")
        if lc in ("address1","addr1","line1"): rename[c] = "address1"
        elif lc in ("address2","addr2","line2"): rename[c] = "address2"
        elif lc in ("address3","addr3","line3"): rename[c] = "address3"
        elif lc == "city": rename[c] = "city"
        elif lc == "state": rename[c] = "state"
        elif lc in ("country","nation"): rename[c] = "country"
        elif lc in ("pincode","pin","zip"): rename[c] = "pincode"
    df = df.rename(columns=rename)
    for req in ["address1","address2","address3","city","state","country","pincode"]:
        if req not in df.columns:
            df[req] = None

    df["raw_text"] = df[["address1","address2","address3","city","state","country","pincode"]]        .astype(str).agg(" ".join, axis=1)

    eng = get_engine()
    with eng.begin() as con:
        con.execute(text("DELETE FROM input.addresses"))
        df[["address1","address2","address3","city","state","country","pincode","raw_text"]]            .to_sql("addresses", con, schema="input", if_exists="append", index=False, method="multi")
    print(f"Loaded {len(df)} rows into input.addresses")

if __name__=="__main__":
    main()
