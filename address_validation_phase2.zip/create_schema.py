from sqlalchemy import text
from sqlalchemy.engine import Engine
from db_config import get_engine

def _is_sqlite(eng: Engine)->bool:
    return eng.url.get_backend_name() == "sqlite"

def main():
    eng = get_engine()
    sqlite = _is_sqlite(eng)

    def pk():
        return "INTEGER PRIMARY KEY AUTOINCREMENT" if sqlite else "BIGSERIAL PRIMARY KEY"

    with eng.begin() as con:
        # Namespaces / schemas
        if sqlite:
            # SQLite has single namespace, but we'll prefix schema names in table names via "schema.table"
            pass
        else:
            con.execute(text("CREATE SCHEMA IF NOT EXISTS ref"))
            con.execute(text("CREATE SCHEMA IF NOT EXISTS input"))
            con.execute(text("CREATE SCHEMA IF NOT EXISTS output"))

        # Reference tables
        con.execute(text(f"""
        CREATE TABLE IF NOT EXISTS ref.countries(
            id {pk()},
            name TEXT UNIQUE
        )
        """))
        con.execute(text(f"""
        CREATE TABLE IF NOT EXISTS ref.world_cities(
            id {pk()},
            city TEXT,
            country TEXT,
            iso2 TEXT,
            iso3 TEXT
        )
        """))
        con.execute(text(f"""
        CREATE TABLE IF NOT EXISTS ref.t30_cities(
            id {pk()},
            city TEXT,
            country TEXT DEFAULT 'India'
        )
        """))
        con.execute(text(f"""
        CREATE TABLE IF NOT EXISTS ref.indian_state_abbrev(
            id {pk()},
            state TEXT,
            abbreviation TEXT
        )
        """))
        con.execute(text(f"""
        CREATE TABLE IF NOT EXISTS ref.postal_pincode(
            id {pk()},
            city TEXT,
            state TEXT,
            pincode TEXT,
            country TEXT DEFAULT 'India'
        )
        """))
        con.execute(text(f"""
        CREATE TABLE IF NOT EXISTS ref.rta_pincode(
            id {pk()},
            city TEXT,
            state TEXT,
            pincode TEXT,
            country TEXT DEFAULT 'India'
        )
        """))

        # Inputs
        con.execute(text(f"""
        CREATE TABLE IF NOT EXISTS input.addresses(
            id {pk()},
            address1 TEXT,
            address2 TEXT,
            address3 TEXT,
            city TEXT,
            state TEXT,
            country TEXT,
            pincode TEXT,
            raw_text TEXT
        )
        """))

        # Outputs
        con.execute(text(f"""
        CREATE TABLE IF NOT EXISTS output.validation_result(
            id {pk()},
            input_id INTEGER,
            chosen_pincode TEXT,
            chosen_city TEXT,
            chosen_state TEXT,
            chosen_country TEXT,
            score_pincode_input_city REAL,
            score_pincode_city_db REAL,
            score_pincode_input_state REAL,
            score_pincode_state_db REAL,
            score_pincode_input_country REAL,
            score_pincode_country_db REAL,
            flag_t30_possible INTEGER,
            flag_foreign_country_possible INTEGER,
            flag_pincode_found INTEGER,
            source_used TEXT,
            all_pincodes TEXT,
            all_cities TEXT,
            all_states TEXT,
            all_countries TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """))

        con.execute(text(f"""
        CREATE TABLE IF NOT EXISTS output.audit_matches(
            id {pk()},
            input_id INTEGER,
            match_type TEXT,
            candidate TEXT,
            score REAL,
            source TEXT
        )
        """))

    print("Phase‑2 schema created (dialect:", eng.url.get_backend_name(), ").")

if __name__ == "__main__":
    main()
