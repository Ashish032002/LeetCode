import os, pandas as pd
from sqlalchemy import text
from db_config import get_engine

def main():
    here = os.path.dirname(__file__)
    path = os.path.join(here, "world_cities.xlsx")
    if not os.path.exists(path):
        raise FileNotFoundError("world_cities.xlsx not found.")
    df = pd.read_excel(path)

    rename = {}
    for c in df.columns:
        lc = c.strip().lower().replace(" ", "")
        if lc == "city": rename[c] = "city"
        elif lc in ("country","countryname","nation"): rename[c] = "country"
        elif lc == "iso2": rename[c] = "iso2"
        elif lc == "iso3": rename[c] = "iso3"
    df = df.rename(columns=rename)
    for req in ["city","country","iso2","iso3"]:
        if req not in df.columns: df[req] = None

    df["city"] = df["city"].astype(str).str.strip().str.title()
    df["country"] = df["country"].astype(str).str.strip().str.title()

    eng = get_engine()
    with eng.begin() as con:
        con.execute(text("DELETE FROM ref.world_cities"))
        df[["city","country","iso2","iso3"]].to_sql("world_cities", con, schema="ref",
                                                    if_exists="append", index=False, method="multi")
    print(f"Loaded {len(df)} rows into ref.world_cities")

if __name__=="__main__":
    main()
