import os, re, pandas as pd
from sqlalchemy import text
from db_config import get_engine

def _norm_pin(s):
    if pd.isna(s): return None
    m = re.search(r"(\d{6})", str(s))
    return m.group(1) if m else None

def _clean_city(x: str) -> str:
    s = str(x or "").strip()
    s = re.sub(r"\bdivision(?: office)?\b", "", s, flags=re.I).strip()
    return re.sub(r"\s+", " ", s).title()

def _pick(cols, cands):
    look = {c.lower().replace(" ",""): c for c in cols}
    for cand in cands:
        k = cand.lower().replace(" ","")
        if k in look: return look[k]
    return None

def main():
    here = os.path.dirname(__file__)
    xlsx = os.path.join(here, "postal_pincode.xlsx")
    csv  = os.path.join(here, "postal_pincode.csv")
    if os.path.exists(xlsx):
        df = pd.read_excel(xlsx)
    elif os.path.exists(csv):
        df = pd.read_csv(csv)
    else:
        raise FileNotFoundError("postal_pincode.(xlsx|csv) not found.")

    div = _pick(df.columns, ["DivisionName","Division","City","CityName","OfficeName"])
    st  = _pick(df.columns, ["StateName","State","State_Name","state"])
    pin = _pick(df.columns, ["Pincode","Pin","Zip","pincode"])
    if not all([div, st, pin]):
        raise ValueError("postal_pincode sheet must have Division/City, State, Pincode")

    out = pd.DataFrame({
        "city": df[div].apply(_clean_city),
        "state": df[st].astype(str).str.strip().str.title(),
        "pincode": df[pin].apply(_norm_pin),
        "country": "India"
    }).dropna(subset=["pincode"]).drop_duplicates(["pincode","city","state"])

    eng = get_engine()
    with eng.begin() as con:
        con.execute(text("DELETE FROM ref.postal_pincode"))
        out.to_sql("postal_pincode", con, schema="ref", if_exists="append", index=False, method="multi")
    print(f"Loaded {len(out)} rows into ref.postal_pincode")

if __name__=="__main__":
    main()
