import os, re, pandas as pd
from sqlalchemy import text
from db_config import get_engine

def _norm_pin(s):
    if pd.isna(s): return None
    m = re.search(r"(\d{6})", str(s))
    return m.group(1) if m else None

def main():
    here = os.path.dirname(__file__)
    path = os.path.join(here, "rta_pincode.xlsx")
    if not os.path.exists(path):
        raise FileNotFoundError("rta_pincode.xlsx not found.")
    df = pd.read_excel(path)

    cols = {c.lower().replace(" ",""): c for c in df.columns}
    city = cols.get("city") or list(df.columns)[0]
    pin  = cols.get("pincode") or cols.get("pin") or cols.get("zip")
    state= cols.get("state")
    if not pin or not state:
        raise ValueError("rta_pincode.xlsx must contain columns: city, state, pincode")

    out = pd.DataFrame({
        "city": df[city].astype(str).str.strip().str.title(),
        "state": df[state].astype(str).str.strip().str.title(),
        "pincode": df[pin].apply(_norm_pin),
        "country": "India"
    }).dropna(subset=["pincode"]).drop_duplicates(["pincode","city","state"])

    eng = get_engine()
    with eng.begin() as con:
        con.execute(text("DELETE FROM ref.rta_pincode"))
        out.to_sql("rta_pincode", con, schema="ref", if_exists="append", index=False, method="multi")
    print(f"Loaded {len(out)} rows into ref.rta_pincode")

if __name__=="__main__":
    main()
