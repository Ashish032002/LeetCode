import os, pandas as pd
from sqlalchemy import text
from db_config import get_engine

def main():
    here = os.path.dirname(__file__)
    path = os.path.join(here, "t30_Cities.xlsx")
    if not os.path.exists(path):
        raise FileNotFoundError("t30_Cities.xlsx not found.")
    df = pd.read_excel(path)

    cols = {c.lower().replace(" ",""): c for c in df.columns}
    city_col = cols.get("city") or list(df.columns)[0]
    out = pd.DataFrame({
        "city": df[city_col].astype(str).str.strip().str.title(),
        "country": "India"
    }).dropna().drop_duplicates()

    eng = get_engine()
    with eng.begin() as con:
        con.execute(text("DELETE FROM ref.t30_cities"))
        out.to_sql("t30_cities", con, schema="ref", if_exists="append", index=False, method="multi")
    print(f"Loaded {len(out)} rows into ref.t30_cities")

if __name__=="__main__":
    main()
