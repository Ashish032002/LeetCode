import os, pandas as pd
from sqlalchemy import text
from db_config import get_engine

def main():
    here = os.path.dirname(__file__)
    for path in [os.path.join(here, "indian_state_abbreviation_list.csv"),
                 os.path.join(here, "Indian_state_abbreviation_list.csv")]:
        if os.path.exists(path):
            df = pd.read_csv(path)
            break
    else:
        raise FileNotFoundError("indian_state_abbreviation_list.csv not found.")

    rename = {}
    for c in df.columns:
        lc = c.strip().lower().replace(" ", "")
        if lc in ("state","statename"): rename[c] = "state"
        elif lc in ("abbr","abbreviation","code"): rename[c] = "abbreviation"
    df = df.rename(columns=rename)
    for req in ["state","abbreviation"]:
        if req not in df.columns: raise ValueError("CSV must contain 'state' and 'abbreviation'.")

    df["state"] = df["state"].astype(str).str.strip().str.title()
    df["abbreviation"] = df["abbreviation"].astype(str).str.strip().str.upper()

    eng = get_engine()
    with eng.begin() as con:
        con.execute(text("DELETE FROM ref.indian_state_abbrev"))
        df[["state","abbreviation"]].to_sql("indian_state_abbrev", con, schema="ref",
                                            if_exists="append", index=False, method="multi")
    print(f"Loaded {len(df)} rows into ref.indian_state_abbrev")

if __name__=="__main__":
    main()
