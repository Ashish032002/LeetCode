
from typing import List, Literal, Optional
from pydantic import BaseModel, Field

class AddressRequest(BaseModel):
    address1: str = Field(..., description="First line of address")
    address2: Optional[str] = Field(None, description="Second line of address")
    address3: Optional[str] = Field(None, description="Third line of address or landmark")
    city: Optional[str] = Field(None, description="City name as provided by user")
    state: Optional[str] = Field(None, description="State name as provided by user")
    pincode: Optional[str] = Field(None, description="Postal PIN code as provided by user")
    country: Optional[str] = Field(None, description="Country name as provided by user")

class NormalizedOutput(BaseModel):
    output_pincode: Optional[str]
    output_city: Optional[str]
    output_state: Optional[str]
    output_country: Optional[str]
    local_address: Optional[str]

class Flags(BaseModel):
    t30_city_possible: int
    foreign_country_possible: int
    pincode_found: int
    ambiguous_address_flag: int

class PossibleValues(BaseModel):
    all_possible_countries: List[str]
    all_possible_states: List[str]
    all_possible_cities: List[str]
    all_possible_pincodes: List[str]

class MatchingScores(BaseModel):
    city_value_match: float
    city_consistency_with_pincode: float
    city_ambiguity_penalty: float
    state_value_match: float
    state_consistency_with_pincode: float
    state_ambiguity_penalty: float
    country_value_match: float
    country_consistency_with_pincode: float
    country_ambiguity_penalty: float
    overall_score: float

class ValidationResult(BaseModel):
    normalized_output: NormalizedOutput
    flags: Flags
    possible_values: PossibleValues
    matching_scores: MatchingScores
    reason: str

class AddressValidationResponse(BaseModel):
    results: List[ValidationResult]
    status: Literal["OK", "ZERO_RESULTS", "INVALID_REQUEST", "REQUEST_DENIED", "UNKNOWN_ERROR"]
    reason: Optional[str] = None
