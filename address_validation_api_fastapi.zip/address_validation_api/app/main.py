
from fastapi import FastAPI
from app.api.v1.address import router as address_router

app = FastAPI(
    title="Address Validation API",
    version="1.0.0",
    description="Single-address validation API backed by the existing validator logic.",
)

app.include_router(address_router)
