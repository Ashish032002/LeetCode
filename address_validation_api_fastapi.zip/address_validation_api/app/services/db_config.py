
import os
from sqlalchemy import create_engine

def get_db_connection():
    """Return a SQLAlchemy engine for the Postgres/AlloyDB instance.

    The preferred way is to set DATABASE_URL, e.g.:
    postgresql+psycopg2://user:password@host:port/dbname
    """
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        user = os.getenv("PGUSER", "postgres")
        password = os.getenv("PGPASSWORD", "")
        host = os.getenv("PGHOST", "localhost")
        port = os.getenv("PGPORT", "5432")
        dbname = os.getenv("PGDATABASE", "postgres")
        db_url = f"postgresql+psycopg2://{user}:{password}@{host}:{port}/{dbname}"
    engine = create_engine(db_url, pool_pre_ping=True)
    return engine
