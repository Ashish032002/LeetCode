
from typing import Dict
import pandas as pd

from app.models.schemas import (
    AddressRequest,
    AddressValidationResponse,
    ValidationResult,
    NormalizedOutput,
    Flags,
    PossibleValues,
    MatchingScores,
)
from app.services.validate_addresses_9_final import validate_inputs_df

def validate_single_address(req: AddressRequest) -> AddressValidationResponse:
    # Build a single-row DataFrame compatible with the existing validator
    df = pd.DataFrame(
        [
            {
                "id": 1,
                "address1": req.address1,
                "address2": req.address2 or "",
                "address3": req.address3 or "",
                "city": req.city or "",
                "state": req.state or "",
                "pincode": req.pincode or "",
                "country": req.country or "",
            }
        ]
    )

    result_df = validate_inputs_df(df, batch_size=1)
    if result_df.empty:
        return AddressValidationResponse(
            results=[],
            status="ZERO_RESULTS",
            reason="No matching city/state/pincode found for given input",
        )

    row = result_df.iloc[0]

    normalized_output = NormalizedOutput(
        output_pincode=row.get("output_pincode"),
        output_city=row.get("output_city"),
        output_state=row.get("output_state"),
        output_country=row.get("output_country"),
        local_address=row.get("local_address"),
    )

    flags = Flags(
        t30_city_possible=int(row.get("t30_city_possible", 0) or 0),
        foreign_country_possible=int(row.get("foreign_country_possible", 0) or 0),
        pincode_found=int(row.get("pincode_found", 0) or 0),
        ambiguous_address_flag=int(row.get("ambiguous_address_flag", 0) or 0),
    )

    import json as _json

    def _parse_list(value):
        if value is None or value == "":
            return []
        if isinstance(value, list):
            return value
        try:
            return list(_json.loads(value))
        except Exception:
            return [str(value)]

    possible_values = PossibleValues(
        all_possible_countries=_parse_list(row.get("all_possible_countries")),
        all_possible_states=_parse_list(row.get("all_possible_states")),
        all_possible_cities=_parse_list(row.get("all_possible_cities")),
        all_possible_pincodes=_parse_list(row.get("all_possible_pincodes")),
    )

    matching_scores = MatchingScores(
        city_value_match=float(row.get("city_value_match", 0) or 0),
        city_consistency_with_pincode=float(row.get("city_consistency_with_pincode", 0) or 0),
        city_ambiguity_penalty=float(row.get("city_ambiguity_penalty", 0) or 0),
        state_value_match=float(row.get("state_value_match", 0) or 0),
        state_consistency_with_pincode=float(row.get("state_consistency_with_pincode", 0) or 0),
        state_ambiguity_penalty=float(row.get("state_ambiguity_penalty", 0) or 0),
        country_value_match=float(row.get("country_value_match", 0) or 0),
        country_consistency_with_pincode=float(row.get("country_consistency_with_pincode", 0) or 0),
        country_ambiguity_penalty=float(row.get("country_ambiguity_penalty", 0) or 0),
        overall_score=float(row.get("overall_score", 0) or 0),
    )

    result = ValidationResult(
        normalized_output=normalized_output,
        flags=flags,
        possible_values=possible_values,
        matching_scores=matching_scores,
        reason=row.get("reason", "") or "",
    )

    return AddressValidationResponse(
        results=[result],
        status="OK",
        reason=result.reason or "Address validated successfully",
    )
