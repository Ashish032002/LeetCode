# Address Validation API (FastAPI)

This repository exposes your existing address validation logic as a FastAPI service.
It is structured to be deployed to Google Cloud Run and to use AlloyDB (PostgreSQL-compatible) as the backing database.

## Project Structure

- `app/main.py` - FastAPI application, health endpoint, router registration
- `app/api/v1/address.py` - `/api/v1/validate-address` endpoint
- `app/core/config.py` - Application and DB configuration via env vars (`ADDRESS_API_*`)
- `app/core/db.py` - SQLAlchemy session factory for AlloyDB
- `app/core/validator.py` - Wrapper around your existing validation logic (plug your code here)
- `app/schemas/` - Pydantic models for request and response, aligned with the agreed API contract
- `tests/` - Simple sample tests (healthcheck)

## Running locally

```bash
python -m venv .venv
source .venv/bin/activate  # or .venv\Scripts\activate on Windows

pip install -r requirements.txt

# Export DB env vars (example)
export ADDRESS_API_DB_HOST=127.0.0.1
export ADDRESS_API_DB_PORT=5432
export ADDRESS_API_DB_NAME=address_validation
export ADDRESS_API_DB_USER=postgres
export ADDRESS_API_DB_PASSWORD=postgres

uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload
```

Open http://localhost:8080/docs for Swagger UI.

## Deployment Notes (Cloud Run / DevOps)

- Expose port `8080` (Cloud Run default).
- Health check: `GET /health`
- Main endpoint: `POST /api/v1/validate-address`

### Example Request

```json
{
  "address1": "9/911 Malviya Nagar",
  "address2": "Near XYZ Temple",
  "address3": null,
  "city": "Jaipur",
  "state": "Rajasthan",
  "pincode": "302017",
  "country": "India"
}
```

### Example Response (Shape)

```json
{
  "results": [
    {
      "normalized_output": {
        "output_pincode": "302017",
        "output_city": "Jaipur",
        "output_state": "Rajasthan",
        "output_country": "India",
        "local_address": "9/911 Malviya Nagar"
      },
      "flags": {
        "t30_city_possible": 1,
        "foreign_country_possible": 0,
        "pincode_found": 1,
        "ambiguous_address_flag": 0
      },
      "possible_values": {
        "all_possible_countries": ["India"],
        "all_possible_states": ["Rajasthan"],
        "all_possible_cities": ["Jaipur"],
        "all_possible_pincodes": ["302017"]
      },
      "matching_scores": {
        "city_value_match": 100,
        "city_consistency_with_pincode": 100,
        "city_ambiguity_penalty": 0,
        "state_value_match": 100,
        "state_consistency_with_pincode": 100,
        "state_ambiguity_penalty": 0,
        "country_value_match": 100,
        "country_consistency_with_pincode": 100,
        "country_ambiguity_penalty": 0,
        "overall_score": 100
      },
      "reason": "Address fully matched and validated"
    }
  ],
  "status": "OK",
  "reason": "Address fully matched and validated"
}
```

## Next Steps for You

1. Copy your existing single-address validation logic into `app/core/validator.py`
   inside `validate_single_address()`. Use `db` session if you want to read from
   AlloyDB tables instead of local CSVs.
2. Commit and push this repo to GitLab.
3. Share with DevOps for cluster / Cloud Run deployment.
