"""Wrapper around your existing address validation logic.

IMPORTANT:
- Plug your current single-address validation function here.
- This module should not know about FastAPI directly; it just takes input models and returns output models.
"""

from sqlalchemy.orm import Session
from ..schemas import (
    AddressInput,
    NormalizedOutput,
    Flags,
    PossibleValues,
    MatchingScores,
    ValidationResult,
    AddressValidationResponse,
)

def validate_single_address(address: AddressInput, db: Session | None = None) -> ValidationResult:
    """Validate a single address and return a structured ValidationResult.

    - `address` is the Pydantic input model with address1, address2, address3, city, state, pincode, country.
    - `db` is an optional SQLAlchemy session if you want to read from AlloyDB tables
      like `master_data` and `pincode_master` instead of CSVs.

    Replace the placeholder implementation below with your full logic.
    """

    # TODO: Replace this dummy implementation with your real validation logic.
    # This is just to show the structure and keep the API contract correct.
    normalized_output = NormalizedOutput(
        output_pincode=address.pincode,
        output_city=address.city,
        output_state=address.state,
        output_country=address.country or "India",
        local_address=address.address1,
    )

    flags = Flags(
        t30_city_possible=0,
        foreign_country_possible=0,
        pincode_found=1 if address.pincode else 0,
        ambiguous_address_flag=0,
    )

    possible_values = PossibleValues(
        all_possible_countries=[normalized_output.output_country] if normalized_output.output_country else [],
        all_possible_states=[normalized_output.output_state] if normalized_output.output_state else [],
        all_possible_cities=[normalized_output.output_city] if normalized_output.output_city else [],
        all_possible_pincodes=[normalized_output.output_pincode] if normalized_output.output_pincode else [],
    )

    matching_scores = MatchingScores(
        city_value_match=100 if address.city else 0,
        city_consistency_with_pincode=100 if address.city and address.pincode else 0,
        city_ambiguity_penalty=0,
        state_value_match=100 if address.state else 0,
        state_consistency_with_pincode=100 if address.state and address.pincode else 0,
        state_ambiguity_penalty=0,
        country_value_match=100 if normalized_output.output_country else 0,
        country_consistency_with_pincode=100 if normalized_output.output_country and address.pincode else 0,
        country_ambiguity_penalty=0,
        overall_score=100 if address.pincode else 50,
    )

    reason = "Dummy validation result - replace with real logic."

    return ValidationResult(
        normalized_output=normalized_output,
        flags=flags,
        possible_values=possible_values,
        matching_scores=matching_scores,
        reason=reason,
    )

def validate_address_to_response(address: AddressInput, db: Session | None = None) -> AddressValidationResponse:
    """Convenience function: returns full AddressValidationResponse for API layer."""
    result = validate_single_address(address, db=db)
    status = "OK" if result.matching_scores.overall_score > 0 else "ZERO_RESULTS"
    return AddressValidationResponse(results=[result], status=status, reason=result.reason)
