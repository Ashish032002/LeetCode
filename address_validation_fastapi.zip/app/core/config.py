import os
from functools import lru_cache
from pydantic import BaseSettings, Field

class Settings(BaseSettings):
    # Basic app settings
    app_name: str = "Address Validation API"
    environment: str = Field(default="dev", description="Environment name: dev/stage/prod")

    # Database (AlloyDB - PostgreSQL compatible)
    db_host: str = Field(default="localhost", description="PostgreSQL/AlloyDB host")
    db_port: int = Field(default=5432, description="PostgreSQL/AlloyDB port")
    db_name: str = Field(default="address_validation", description="Database name")
    db_user: str = Field(default="postgres", description="Database user")
    db_password: str = Field(default="postgres", description="Database password")

    class Config:
        env_prefix = "ADDRESS_API_"
        case_sensitive = False

    @property
    def sqlalchemy_database_uri(self) -> str:
        return (
            f"postgresql+psycopg2://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

@lru_cache()
def get_settings() -> Settings:
    return Settings()
