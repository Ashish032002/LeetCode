from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ...schemas import AddressInput, AddressValidationResponse
from ...core.db import get_db
from ...core.validator import validate_address_to_response

router = APIRouter(prefix="/api/v1", tags=["address-validation"])

@router.post(
    "/validate-address",
    response_model=AddressValidationResponse,
    summary="Validate a single address",
    response_description="Normalized address, flags, possible values, and matching scores",
)
async def validate_address(
    payload: AddressInput,
    db: Session = Depends(get_db),
) -> AddressValidationResponse:
    """Validate a single address and return normalized output and scores.

    This endpoint is intended for online calls from other services.
    Bulk .xlsx processing should continue to be handled by your offline script.
    """

    try:
        response = validate_address_to_response(payload, db=db)
    except Exception as exc:  # pragma: no cover - generic safeguard
        # If your validator raises custom exceptions, handle them explicitly here.
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Validation failed: {exc}",
        ) from exc

    return response
