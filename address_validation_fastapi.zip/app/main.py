from fastapi import FastAPI
from .api.v1.address import router as address_router

app = FastAPI(
    title="Address Validation API",
    version="1.0.0",
    description="API for validating Indian postal addresses and returning normalized output, flags, and scores.",
)

@app.get("/health", tags=["health"])
async def health_check():
    return {"status": "OK"}

app.include_router(address_router)
