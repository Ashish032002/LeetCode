from pydantic import BaseModel, Field
from typing import Optional

class AddressInput(BaseModel):
    address1: str = Field(..., description="Primary address line, typically house/flat number and street")
    address2: Optional[str] = Field(None, description="Secondary address line (optional)")
    address3: Optional[str] = Field(None, description="Tertiary address line (optional)")
    city: Optional[str] = Field(None, description="City or locality as provided in raw input")
    state: Optional[str] = Field(None, description="State as provided in raw input")
    pincode: Optional[str] = Field(None, description="6-digit Indian postal code as provided in raw input")
    country: Optional[str] = Field(None, description="Country name as provided in raw input")

    class Config:
        json_schema_extra = {
            "example": {
                "address1": "9/911 Malviya Nagar",
                "address2": "Near XYZ Temple",
                "address3": None,
                "city": "Jaipur",
                "state": "Rajasthan",
                "pincode": "302017",
                "country": "India",
            }
        }
