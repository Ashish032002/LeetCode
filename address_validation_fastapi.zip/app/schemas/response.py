from pydantic import BaseModel, Field
from typing import List, Optional

class NormalizedOutput(BaseModel):
    output_pincode: Optional[str] = Field(None, description="Validated/normalized pincode")
    output_city: Optional[str] = Field(None, description="Validated/normalized city")
    output_state: Optional[str] = Field(None, description="Validated/normalized state")
    output_country: Optional[str] = Field(None, description="Validated/normalized country")
    local_address: Optional[str] = Field(None, description="Normalized local address text")

class Flags(BaseModel):
    t30_city_possible: int = Field(..., description="Flag for T30 city possibility")
    foreign_country_possible: int = Field(..., description="Flag indicating if foreign country is possible")
    pincode_found: int = Field(..., description="Flag indicating if pincode was found")
    ambiguous_address_flag: int = Field(..., description="Flag for overall address ambiguity")

class PossibleValues(BaseModel):
    all_possible_countries: List[str] = Field(default_factory=list)
    all_possible_states: List[str] = Field(default_factory=list)
    all_possible_cities: List[str] = Field(default_factory=list)
    all_possible_pincodes: List[str] = Field(default_factory=list)

class MatchingScores(BaseModel):
    city_value_match: int
    city_consistency_with_pincode: int
    city_ambiguity_penalty: int
    state_value_match: int
    state_consistency_with_pincode: int
    state_ambiguity_penalty: int
    country_value_match: int
    country_consistency_with_pincode: int
    country_ambiguity_penalty: int
    overall_score: int

class ValidationResult(BaseModel):
    normalized_output: NormalizedOutput
    flags: Flags
    possible_values: PossibleValues
    matching_scores: MatchingScores
    reason: str

class AddressValidationResponse(BaseModel):
    results: list[ValidationResult] = Field(default_factory=list)
    status: str
    reason: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "results": [
                    {
                        "normalized_output": {
                            "output_pincode": "302017",
                            "output_city": "Jaipur",
                            "output_state": "Rajasthan",
                            "output_country": "India",
                            "local_address": "9/911 Malviya Nagar"
                        },
                        "flags": {
                            "t30_city_possible": 1,
                            "foreign_country_possible": 0,
                            "pincode_found": 1,
                            "ambiguous_address_flag": 0
                        },
                        "possible_values": {
                            "all_possible_countries": ["India"],
                            "all_possible_states": ["Rajasthan"],
                            "all_possible_cities": ["Jaipur"],
                            "all_possible_pincodes": ["302017"]
                        },
                        "matching_scores": {
                            "city_value_match": 100,
                            "city_consistency_with_pincode": 100,
                            "city_ambiguity_penalty": 0,
                            "state_value_match": 100,
                            "state_consistency_with_pincode": 100,
                            "state_ambiguity_penalty": 0,
                            "country_value_match": 100,
                            "country_consistency_with_pincode": 100,
                            "country_ambiguity_penalty": 0,
                            "overall_score": 100
                        },
                        "reason": "Address fully matched and validated"
                    }
                ],
                "status": "OK",
                "reason": "Address fully matched and validated"
            }
        }
